<?php


//Masukkan PHPSESSID
$PHPSESSID = '54654756ytryrt75685456';
//Masukkan GA
$_ga = 'GA1.2.2105677657.17560730';
//Masukkan GID
$_gid = 'GA1.2.135757924809.1575572';



?>
